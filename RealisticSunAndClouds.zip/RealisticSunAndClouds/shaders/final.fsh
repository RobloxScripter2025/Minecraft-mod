
uniform vec3 sunPosition;
uniform float time;

float rand(vec2 co){
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

float noise(vec2 p){
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = rand(i);
    float b = rand(i + vec2(1.0, 0.0));
    float c = rand(i + vec2(0.0, 1.0));
    float d = rand(i + vec2(1.0, 1.0));
    vec2 u = f*f*(3.0-2.0*f);
    return mix(a, b, u.x) + (c - a)* u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

void main() {
    vec2 uv = gl_FragCoord.xy / vec2(1280.0, 720.0); // screen ratio approx.
    vec3 skyColor = vec3(0.5, 0.7, 1.0);
    
    // Add simple clouds using noise
    float clouds = noise(uv * 10.0 + time * 0.02);
    clouds = smoothstep(0.4, 0.6, clouds);

    // Simulate sun glow
    float sun = smoothstep(0.05, 0.01, distance(uv, vec2(0.75, 0.25)));
    vec3 sunColor = vec3(1.0, 0.9, 0.6) * sun;

    vec3 finalColor = mix(skyColor, vec3(1.0), clouds * 0.3) + sunColor;
    gl_FragColor = vec4(finalColor, 1.0);
}
